import javax.swing.*;

public class LeaveApproval extends JFrame {

    LeaveApproval() {

        // JFrame
        setTitle("Leave Approval");
        setSize(650, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        // ---------------- JLabel ----------------

        JLabel title = new JLabel("LEAVE APPROVAL");
        title.setBounds(240, 30, 200, 40);
        add(title);


        JLabel faculty = new JLabel("Faculty Name:");
        faculty.setBounds(70, 100, 120, 30);
        add(faculty);


        JLabel leaveType = new JLabel("Leave Type:");
        leaveType.setBounds(70, 150, 120, 30);
        add(leaveType);


        JLabel fromDate = new JLabel("From Date:");
        fromDate.setBounds(70, 200, 120, 30);
        add(fromDate);


        JLabel toDate = new JLabel("To Date:");
        toDate.setBounds(70, 250, 120, 30);
        add(toDate);


        JLabel status = new JLabel("Status:");
        status.setBounds(70, 300, 120, 30);
        add(status);


        JLabel reason = new JLabel("Reason:");
        reason.setBounds(350, 100, 100, 30);
        add(reason);


        // ---------------- JTextField ----------------

        JTextField facultyField = new JTextField();
        facultyField.setBounds(180, 100, 150, 30);
        add(facultyField);


        JTextField leaveField = new JTextField();
        leaveField.setBounds(180, 150, 150, 30);
        add(leaveField);


        JTextField fromField = new JTextField();
        fromField.setBounds(180, 200, 150, 30);
        add(fromField);


        JTextField toField = new JTextField();
        toField.setBounds(180, 250, 150, 30);
        add(toField);


        JTextField statusField = new JTextField("Pending");
        statusField.setBounds(180, 300, 150, 30);
        statusField.setEditable(false);
        add(statusField);


        // ---------------- JTextArea ----------------

        JTextArea reasonArea = new JTextArea();
        reasonArea.setBounds(420, 100, 170, 100);
        add(reasonArea);


        // ---------------- JButton ----------------

        JButton approve = new JButton("Approve");
        approve.setBounds(150, 370, 120, 40);
        add(approve);


        JButton reject = new JButton("Reject");
        reject.setBounds(280, 370, 120, 40);
        add(reject);


        JButton clear = new JButton("Clear");
        clear.setBounds(410, 370, 100, 40);
        add(clear);


        // ---------------- Approve ----------------

        approve.addActionListener(e -> {

            statusField.setText("Approved");

            JOptionPane.showMessageDialog(
                    this,
                    "Leave Approved Successfully"
            );

        });


        // ---------------- Reject ----------------

        reject.addActionListener(e -> {

            statusField.setText("Rejected");

            JOptionPane.showMessageDialog(
                    this,
                    "Leave Rejected"
            );

        });


        // ---------------- Clear ----------------

        clear.addActionListener(e -> {

            facultyField.setText("");
            leaveField.setText("");
            fromField.setText("");
            toField.setText("");
            reasonArea.setText("");
            statusField.setText("Pending");

        });


        // Show JFrame
        setVisible(true);
    }


    public static void main(String[] args) {

        new LeaveApproval();

    }
}