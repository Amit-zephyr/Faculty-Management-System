import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LeaveSubstitutionRecords extends JFrame {

    LeaveSubstitutionRecords() {

        setTitle("Leave / Substitution Records");
        setSize(800, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("LEAVE / SUBSTITUTION RECORDS");
        title.setBounds(280, 30, 300, 40);
        add(title);

        JLabel searchLabel = new JLabel("Search Faculty:");
        searchLabel.setBounds(50, 90, 120, 30);
        add(searchLabel);

        JTextField searchField = new JTextField();
        searchField.setBounds(160, 90, 180, 30);
        add(searchField);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(350, 90, 100, 30);
        add(searchButton);

        String[] columns = {
                "Faculty",
                "Leave Type",
                "From Date",
                "To Date",
                "Status",
                "Substitute"
        };

        Object[][] data = {
                {"Amit Sharma", "Casual Leave", "01-09-2026",
                        "02-09-2026", "Approved", "Rahul Sharma"},

                {"Neha Verma", "Medical Leave", "03-09-2026",
                        "04-09-2026", "Pending", "Amit Kumar"},

                {"Rahul Sharma", "Earned Leave", "05-09-2026",
                        "06-09-2026", "Rejected", "Priya Singh"},

                {"Amit Sharma", "Medical Leave", "08-09-2026",
                        "09-09-2026", "Approved", "Neha Verma"}
        };

        JTable table = new JTable(
                new DefaultTableModel(data, columns)
        );

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 140, 700, 220);
        add(scrollPane);

        JButton refresh = new JButton("Refresh");
        refresh.setBounds(250, 390, 100, 40);
        add(refresh);

        JButton close = new JButton("Close");
        close.setBounds(370, 390, 100, 40);
        add(close);

        searchButton.addActionListener(e -> {

            String name = searchField.getText();

            if (name.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter faculty name"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Searching records for: " + name
                );
            }
        });

        refresh.addActionListener(e -> {

            searchField.setText("");

            JOptionPane.showMessageDialog(
                    this,
                    "Records Refreshed"
            );
        });

        close.addActionListener(e -> dispose());

        setVisible(true);
    }

    public static void main(String[] args) {
        new LeaveSubstitutionRecords();
    }
}