import javax.swing.*;

public class ApplyLeave extends JFrame {

    ApplyLeave() {

        // JFrame
        setTitle("Apply Leave");
        setSize(600, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        // ---------------- JLabel ----------------

        JLabel title = new JLabel("APPLY LEAVE");
        title.setBounds(230, 30, 200, 40);
        add(title);


        JLabel leaveType = new JLabel("Leave Type:");
        leaveType.setBounds(70, 100, 100, 30);
        add(leaveType);


        JLabel fromDate = new JLabel("From Date:");
        fromDate.setBounds(70, 150, 100, 30);
        add(fromDate);


        JLabel toDate = new JLabel("To Date:");
        toDate.setBounds(70, 200, 100, 30);
        add(toDate);


        JLabel reason = new JLabel("Reason:");
        reason.setBounds(70, 250, 100, 30);
        add(reason);


        JLabel contact = new JLabel("Contact No:");
        contact.setBounds(320, 100, 100, 30);
        add(contact);


        JLabel email = new JLabel("Email:");
        email.setBounds(320, 150, 100, 30);
        add(email);


        // ---------------- JComboBox ----------------

        String[] leaves = {
                "Casual Leave",
                "Medical Leave",
                "Earned Leave"
        };

        JComboBox<String> leaveBox =
                new JComboBox<>(leaves);

        leaveBox.setBounds(170, 100, 130, 30);
        add(leaveBox);


        // ---------------- JTextField ----------------

        JTextField fromField = new JTextField();
        fromField.setBounds(170, 150, 130, 30);
        add(fromField);


        JTextField toField = new JTextField();
        toField.setBounds(170, 200, 130, 30);
        add(toField);


        JTextField contactField = new JTextField();
        contactField.setBounds(420, 100, 130, 30);
        add(contactField);


        JTextField emailField = new JTextField();
        emailField.setBounds(420, 150, 130, 30);
        add(emailField);


        // ---------------- JTextArea ----------------

        JTextArea reasonArea = new JTextArea();
        reasonArea.setBounds(170, 250, 380, 80);
        add(reasonArea);


        // ---------------- JButton ----------------

        JButton submit = new JButton("Submit Leave");
        submit.setBounds(170, 360, 130, 40);
        add(submit);


        JButton clear = new JButton("Clear");
        clear.setBounds(320, 360, 100, 40);
        add(clear);


        JButton cancel = new JButton("Cancel");
        cancel.setBounds(440, 360, 100, 40);
        add(cancel);


        // ---------------- Submit Button ----------------

        submit.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    this,
                    "Leave Application Submitted"
            );

        });


        // ---------------- Clear Button ----------------

        clear.addActionListener(e -> {

            fromField.setText("");
            toField.setText("");
            contactField.setText("");
            emailField.setText("");
            reasonArea.setText("");

        });


        // ---------------- Cancel Button ----------------

        cancel.addActionListener(e -> {

            dispose();

        });


        // Show window
        setVisible(true);
    }


    public static void main(String[] args) {

        new ApplyLeave();

    }
}