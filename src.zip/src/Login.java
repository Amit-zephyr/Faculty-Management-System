import javax.swing.*;
import java.awt.*;

public class Login extends JFrame {

    // JLabel
    JLabel titleLabel;
    JLabel userLabel;
    JLabel passwordLabel;
    JLabel roleLabel;

    // Input fields
    JTextField userField;
    JPasswordField passwordField;

    // JComboBox
    JComboBox<String> roleBox;

    // JButton
    JButton loginButton;
    JButton resetButton;

    Login() {

        // JFrame settings
        setTitle("Login");
        setSize(600, 450);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ---------------- TITLE ----------------

        titleLabel = new JLabel(
                "FACULTY LEAVE & SUBSTITUTION MANAGEMENT SYSTEM"
        );

        titleLabel.setFont(
                new Font("Arial", Font.BOLD, 20)
        );

        titleLabel.setForeground(new Color(20, 55, 130));

        titleLabel.setBounds(75, 40, 480, 35);

        add(titleLabel);


        // ---------------- USER ID ----------------

        userLabel = new JLabel("User ID:");

        userLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        userLabel.setBounds(120, 120, 100, 30);

        add(userLabel);


        userField = new JTextField();

        userField.setBounds(230, 120, 220, 30);

        add(userField);


        // ---------------- PASSWORD ----------------

        passwordLabel = new JLabel("Password:");

        passwordLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        passwordLabel.setBounds(120, 170, 100, 30);

        add(passwordLabel);


        passwordField = new JPasswordField();

        passwordField.setBounds(230, 170, 220, 30);

        add(passwordField);


        // ---------------- ROLE ----------------

        roleLabel = new JLabel("Role:");

        roleLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        roleLabel.setBounds(120, 220, 100, 30);

        add(roleLabel);


        String[] roles = {
                "Faculty",
                "Admin / HOD",
                "Substitute Faculty"
        };

        roleBox = new JComboBox<>(roles);

        roleBox.setBounds(230, 220, 220, 30);

        add(roleBox);


        // ---------------- LOGIN BUTTON ----------------

        loginButton = new JButton("Login");

        loginButton.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        loginButton.setBounds(180, 290, 110, 40);

        add(loginButton);


        // ---------------- RESET BUTTON ----------------

        resetButton = new JButton("Reset");

        resetButton.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        resetButton.setBounds(310, 290, 110, 40);

        add(resetButton);


        // ---------------- LOGIN ACTION ----------------

        loginButton.addActionListener(e -> {

            String userId = userField.getText();

            String password =
                    new String(passwordField.getPassword());

            String role =
                    (String) roleBox.getSelectedItem();


            if (userId.isEmpty() || password.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter User ID and Password",
                        "Login Error",
                        JOptionPane.ERROR_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Login Successful!\n"
                                + "User ID: " + userId
                                + "\nRole: " + role,
                        "Login",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        });


        // ---------------- RESET ACTION ----------------

        resetButton.addActionListener(e -> {

            userField.setText("");

            passwordField.setText("");

            roleBox.setSelectedIndex(0);

        });


        // ---------------- BACKGROUND ----------------

        getContentPane().setBackground(
                new Color(240, 245, 252)
        );


        // Show window
        setVisible(true);
    }


    // ---------------- MAIN METHOD ----------------

    public static void main(String[] args) {

        new Login();

    }
}