import javax.swing.*;
import java.awt.*;

public class FacultyDashboard extends JFrame {

    FacultyDashboard() {

        // JFrame
        setTitle("Faculty Leave Management System");
        setSize(700, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Background
        getContentPane().setBackground(Color.WHITE);

        // ---------------- JLabel ----------------

        JLabel title = new JLabel("FACULTY DASHBOARD");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setBounds(240, 30, 300, 40);
        add(title);

        JLabel welcome = new JLabel("Welcome, Amit Sharma");
        welcome.setBounds(500, 75, 160, 30);
        add(welcome);


        // ---------------- JPanel ----------------

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(20, 90, 150, 330);
        add(panel);


        // ---------------- JButton ----------------

        JButton dashboard = new JButton("Dashboard");
        dashboard.setBounds(10, 20, 130, 40);
        panel.add(dashboard);

        JButton applyLeave = new JButton("Apply Leave");
        applyLeave.setBounds(10, 70, 130, 40);
        panel.add(applyLeave);

        JButton myLeaves = new JButton("My Leaves");
        myLeaves.setBounds(10, 120, 130, 40);
        panel.add(myLeaves);

        JButton substitution = new JButton("Substitution");
        substitution.setBounds(10, 170, 130, 40);
        panel.add(substitution);

        JButton records = new JButton("Records");
        records.setBounds(10, 220, 130, 40);
        panel.add(records);

        JButton logout = new JButton("Logout");
        logout.setBounds(10, 270, 130, 40);
        panel.add(logout);


        // ---------------- Leave Information ----------------

        JLabel total = new JLabel("Total Leaves: 5");
        total.setFont(new Font("Arial", Font.BOLD, 18));
        total.setBounds(220, 130, 200, 40);
        add(total);

        JLabel approved = new JLabel("Approved Leaves: 3");
        approved.setFont(new Font("Arial", Font.BOLD, 18));
        approved.setBounds(220, 190, 250, 40);
        add(approved);

        JLabel pending = new JLabel("Pending Leaves: 2");
        pending.setFont(new Font("Arial", Font.BOLD, 18));
        pending.setBounds(220, 250, 250, 40);
        add(pending);

        JLabel substitute = new JLabel("Substitution Assigned: 4");
        substitute.setFont(new Font("Arial", Font.BOLD, 18));
        substitute.setBounds(220, 310, 300, 40);
        add(substitute);


        // ---------------- Button Action ----------------

        applyLeave.addActionListener(e ->
                JOptionPane.showMessageDialog(
                        this,
                        "Apply Leave Page"
                )
        );

        myLeaves.addActionListener(e ->
                JOptionPane.showMessageDialog(
                        this,
                        "My Leaves"
                )
        );

        substitution.addActionListener(e ->
                JOptionPane.showMessageDialog(
                        this,
                        "Substitution Details"
                )
        );

        records.addActionListener(e ->
                JOptionPane.showMessageDialog(
                        this,
                        "Leave / Substitution Records"
                )
        );

        logout.addActionListener(e -> {
            JOptionPane.showMessageDialog(
                    this,
                    "Logout Successfully"
            );
        });


        // Show JFrame
        setVisible(true);
    }


    public static void main(String[] args) {

        new FacultyDashboard();

    }
}

