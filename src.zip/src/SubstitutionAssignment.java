import javax.swing.*;

public class SubstitutionAssignment extends JFrame {

    SubstitutionAssignment() {

        setTitle("Substitution Assignment");
        setSize(650, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("SUBSTITUTION ASSIGNMENT");
        title.setBounds(220, 30, 250, 40);
        add(title);

        JLabel faculty = new JLabel("Absent Faculty:");
        faculty.setBounds(70, 100, 120, 30);
        add(faculty);

        JLabel subject = new JLabel("Subject:");
        subject.setBounds(70, 150, 120, 30);
        add(subject);

        JLabel date = new JLabel("Date:");
        date.setBounds(70, 200, 120, 30);
        add(date);

        JLabel period = new JLabel("Period:");
        period.setBounds(70, 250, 120, 30);
        add(period);

        JLabel substitute = new JLabel("Substitute Faculty:");
        substitute.setBounds(330, 100, 140, 30);
        add(substitute);

        JTextField facultyField = new JTextField();
        facultyField.setBounds(190, 100, 120, 30);
        add(facultyField);

        JTextField subjectField = new JTextField();
        subjectField.setBounds(190, 150, 120, 30);
        add(subjectField);

        JTextField dateField = new JTextField();
        dateField.setBounds(190, 200, 120, 30);
        add(dateField);

        JTextField periodField = new JTextField();
        periodField.setBounds(190, 250, 120, 30);
        add(periodField);

        String[] facultyList = {
                "Select Faculty",
                "Rahul Sharma",
                "Neha Verma",
                "Amit Kumar",
                "Priya Singh"
        };

        JComboBox<String> substituteBox =
                new JComboBox<>(facultyList);

        substituteBox.setBounds(470, 100, 140, 30);
        add(substituteBox);

        JButton assign = new JButton("Assign");
        assign.setBounds(180, 340, 110, 40);
        add(assign);

        JButton clear = new JButton("Clear");
        clear.setBounds(300, 340, 110, 40);
        add(clear);

        JButton cancel = new JButton("Cancel");
        cancel.setBounds(420, 340, 110, 40);
        add(cancel);

        assign.addActionListener(e -> {

            String absentFaculty = facultyField.getText();
            String subjectName = subjectField.getText();
            String selectedFaculty =
                    (String) substituteBox.getSelectedItem();

            if (absentFaculty.isEmpty() ||
                    subjectName.isEmpty() ||
                    selectedFaculty.equals("Select Faculty")) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter all details"
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Substitution Assigned Successfully"
                );
            }
        });

        clear.addActionListener(e -> {

            facultyField.setText("");
            subjectField.setText("");
            dateField.setText("");
            periodField.setText("");
            substituteBox.setSelectedIndex(0);
        });

        cancel.addActionListener(e -> dispose());

        setVisible(true);
    }

    public static void main(String[] args) {
        new SubstitutionAssignment();
    }
}